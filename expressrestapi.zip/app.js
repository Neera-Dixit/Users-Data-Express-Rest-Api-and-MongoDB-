var express=require('express'),
	mongoose=require('mongoose');

var app=express();

var db= mongoose.connect('mongodb://localhost/bookApi');

var book=require('./models/bookModel');

var port = process.env.PORT || 3078;

var bookRouter=express.Router();

bookRouter.route("/books")
	.get(function(req,res){
		book.find(function(err,books){
			if(err){
				console.log(err);
			}
			else{
				res.json(books);
			}
		});
		var resData={book:"C prog"};
		res.json(resData);
	});

app.use("/",bookRouter);

app.listen(port,function(){
	console.log("Server listening at "+port);
});

